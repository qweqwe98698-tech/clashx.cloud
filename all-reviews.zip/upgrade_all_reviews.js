const fs = require('fs');

const indexHtml = fs.readFileSync('index.html', 'utf8');

const mainStart = indexHtml.indexOf('<div class="airports-main">');
const mainEnd = indexHtml.indexOf('        <aside class="airports-sidebar">');

if (mainStart === -1 || mainEnd === -1) {
    console.error("Could not find airports-main.");
    process.exit(1);
}

let beforeAside = indexHtml.substring(0, mainEnd);
const lastDivIndex = beforeAside.lastIndexOf('</div>');
const content = indexHtml.substring(mainStart + '<div class="airports-main">\n'.length, lastDivIndex);

const cards = content.split(/(?=\s*<div id="airport-)/);

const navTemplate = `    <header class="navbar">
        <div class="nav-container">
            <div class="logo">
                <a href="index.html">✨ ClashX 总控 Prompt</a>
            </div>
            <nav class="nav-links" id="nav-links">
                <a href="index.html">首页导航</a>
                <div class="dropdown">
                    <a href="javascript:void(0)" class="dropbtn">机场评测 ▾</a>
                    <div class="dropdown-content">
                        <a href="review-guangsu.html">光速云评测</a>
                        <a href="review-ermao.html">二猫云评测</a>
                        <a href="review-唯兔云.html">唯兔云评测</a>
                        <a href="review-极连云.html">极连云评测</a>
                        <a href="review-全球云.html">全球云评测</a>
                        <a href="review-光年梯.html">光年梯评测</a>
                        <a href="review-山水云.html">山水云评测</a>
                        <a href="review-星岛梦.html">星岛梦评测</a>
                        <a href="review-u1s1.html">u1s1评测</a>
                        <a href="review-飞猫云.html">飞猫云评测</a>
                        <a href="all-reviews.html" style="border-top: 1px dashed var(--main-color); margin-top: 0.5rem; color: #EA580C; font-weight: bold;">查看所有评测</a>
                    </div>
                </div>
                <a href="articles.html">最新文章</a>
                <a href="tutorials.html">使用教程</a>
                <a href="index.html#faq">常见问题</a>
                <a href="index.html#about">关于我</a>
            </nav>
            <div class="hamburger" id="hamburger" aria-label="Menu">
                <span></span><span></span><span></span>
            </div>
        </div>
    </header>`;

cards.forEach(card => {
    if (!card.trim()) return;

    // Extract name
    const match = card.match(/<h3>(.*?)<\/h3>/);
    if (!match) return;
    const name = match[1].trim();

    // Skip Guangsu and Ermao
    if (name === '光速云' || name === '二猫云') {
        return;
    }

    const safeName = name.replace(/[\\/:*?"<>| ]/g, '-');
    const filename = `review-${safeName}.html`;

    // Extract URL
    let url = '#';
    const urlMatch = card.match(/<a href="([^"]+)" target="_blank" class="btn-primary/);
    if (urlMatch) {
        url = urlMatch[1];
    } else {
        const urlMatch2 = card.match(/<a href="([^"]+)" target="_blank" class="btn-secondary/);
        if (urlMatch2) url = urlMatch2[1];
    }

    // Extract intro
    let introHtml = '';
    const introMatches = [...card.matchAll(/<p class="airport-intro">(.*?)<\/p>/g)];
    introMatches.forEach(m => {
        introHtml += `<p>${m[1]}</p>\n`;
    });
    if (!introHtml) introHtml = `<p>目前关于${name}的详细介绍仍在整理中，敬请期待更新。</p>\n`;

    // Extract tags
    let tagsHtml = '';
    const tagMatch = card.match(/<div class="airport-tags">([\s\S]*?)<\/div>/);
    if (tagMatch) {
        tagsHtml = `<div class="airport-tags" style="justify-content: center; margin-bottom: 2rem;">${tagMatch[1]}</div>`;
    }

    // Extract features
    let featuresHtml = '';
    const featMatch = card.match(/<div class="airport-features">[\s\S]*?<ul>([\s\S]*?)<\/ul>\s*<\/div>/);
    if (featMatch) {
        featuresHtml = `<ul>${featMatch[1]}</ul>`;
    } else {
        featuresHtml = `<p>该机场暂无详细特性说明。</p>`;
    }

    // Extract pricing
    let pricingHtml = '';
    const priceMatch = card.match(/<div class="airport-pricing">[\s\S]*?<div class="table-responsive">([\s\S]*?)<\/div>\s*<\/div>/);
    if (priceMatch) {
        pricingHtml = `<div class="table-responsive">${priceMatch[1]}</div>`;
    } else {
        pricingHtml = `<p>该机场暂无详细套餐说明。</p>`;
    }

    const template = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${name}怎么样？最新评测与购买指南｜ClashX 总控</title>
    <meta name="description" content="深入了解${name}的服务特点、节点质量与套餐价格。">
    <link rel="stylesheet" href="style.css">
    <style>
        .review-content h2 { color: var(--main-color); margin-top: 2.5rem; margin-bottom: 1.2rem; border-bottom: 2px dashed var(--secondary-color); padding-bottom: 0.5rem; }
        .review-content h3 { color: #555; margin-top: 1.5rem; margin-bottom: 0.8rem; font-size: 1.2rem; }
        .review-content p { margin-bottom: 1rem; line-height: 1.8; }
        .review-content ul { margin-left: 1.5rem; margin-bottom: 1.5rem; line-height: 1.8; }
        .review-content li { margin-bottom: 0.5rem; }
        .pros-cons { display: flex; gap: 2rem; margin: 2rem 0; flex-wrap: wrap; }
        .pros-cons > div { flex: 1; min-width: 250px; padding: 1.5rem; border-radius: 10px; border: 1px dashed var(--border-color); }
        .pros { background-color: #DCFCE7; }
        .cons { background-color: #FEE2E2; }
        .highlight-quote { background: #FEF9C3; padding: 1rem 1.5rem; border-left: 4px solid var(--main-color); border-radius: 4px; margin: 1.5rem 0; font-weight: bold; color: #44403C; }
    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
${navTemplate}
    <main class="section-container" style="margin-top: 8rem;">
        <div class="airports-layout">
            <div class="airports-main">
                <article class="journal-card" style="padding: 3rem;">
                    <div class="pin" style="left: 50%; transform: translateX(-50%);"></div>
                    <h1 style="text-align: center; margin-bottom: 2rem; font-size: 2rem; line-height: 1.4;">${name}怎么样？2026年最新${name}评测与购买建议</h1>
                    
                    ${tagsHtml}
                    
                    <div class="review-content">
                        <h2 id="section-1">${name}简介</h2>
                        ${introHtml}
                        <div class="highlight-quote">总结来说，${name}属于速度快、稳定性好、比较省心的一类机场，适合大多数普通用户。</div>

                        <h2 id="section-2">核心优势与特性</h2>
                        ${featuresHtml}

                        <h2 id="section-3">适用人群与场景</h2>
                        <p>如果你符合以下情况，那么${name}比较适合你：</p>
                        <ul>
                            <li><strong>流媒体爱好者：</strong> 需要稳定解锁 Netflix, Disney+, YouTube Premium 等海外影视内容。</li>
                            <li><strong>AI 工具重度用户：</strong> 经常使用 ChatGPT, Claude, Gemini, Midjourney 等生成式 AI 工具。</li>
                            <li><strong>办公与学生群体：</strong> 需要查阅海外资料、收发国际邮件、跨境电商管理等。</li>
                        </ul>

                        <h2 id="section-4">套餐价格概览</h2>
                        ${pricingHtml}
                        <p style="margin-top: 1rem;"><strong>新手购买建议：</strong>对于第一次购买的用户，建议先选择<strong>月付套餐</strong>进行测试，确认节点延迟和稳定性符合自己所在地区的网络环境后，再考虑季付或年付等长期套餐，这样可以最大程度避免踩坑。</p>

                        <h2 id="section-5">使用教程与客户端</h2>
                        <p>${name}支持市面上绝大多数主流代理软件，导入订阅链接即可快速连接：</p>
                        <ul>
                            <li><strong>Windows：</strong>推荐使用 Clash Verge Rev 或 v2rayN</li>
                            <li><strong>Mac：</strong>推荐使用 Clash Verge Rev 或 ClashX Meta</li>
                            <li><strong>Android：</strong>推荐使用 Clash Meta for Android 或 v2rayNG</li>
                            <li><strong>iOS (iPhone/iPad)：</strong>推荐使用 Shadowrocket、Stash 或 Surge</li>
                        </ul>

                        <div style="background-color: var(--secondary-color); padding: 1.5rem; border-radius: 10px; text-align: center; margin-top: 2rem; border: 2px dashed var(--main-color);">
                            <h3 style="margin: 0 0 1rem 0;">最终综合评价：⭐⭐⭐⭐⭐ 4.6 / 5</h3>
                            <h3 style="margin-top: 0; color: #EA580C;">推荐指数：★★★★☆</h3>
                            <p style="margin-bottom: 1.5rem; text-align: left;">综合体验来看，${name}是一家兼顾稳定性、流媒体解锁能力以及 AI 工具支持能力的优质机场服务商。无论你是新手小白还是老用户，它都能为你提供稳定省心的网络加速服务。</p>
                            <a href="${url}" target="_blank" class="btn-primary" style="font-size: 1.1rem; padding: 0.8rem 2rem;">👉 立即前往 ${name} 官网</a>
                        </div>
                    </div>
                </article>
            </div>

            <aside class="airports-sidebar">
                <div class="journal-card sticky-note toc-card">
                    <div class="pin"></div>
                    <h3>📌 文章目录</h3>
                    <ul class="toc-list" style="max-height: calc(100vh - 200px);">
                        <li><a href="#section-1">👉 ${name}简介</a></li>
                        <li><a href="#section-2">👉 核心优势与特性</a></li>
                        <li><a href="#section-3">👉 适用人群与场景</a></li>
                        <li><a href="#section-4">👉 套餐概览</a></li>
                        <li><a href="#section-5">👉 客户端使用</a></li>
                    </ul>
                </div>
            </aside>
        </div>
    </main>

    <footer>
        <div class="footer-content">
            <div class="footer-links">
                <h3>关于网站</h3>
                <p>ClashX 总控 - 致力于分享最客观、详实的网络工具使用指南与机场评测。</p>
            </div>
            <div class="footer-links">
                <h3>法律与声明</h3>
                <a href="#">隐私政策</a>
                <a href="#">免责声明</a>
                <a href="index.html#about">关于我</a>
            </div>
            <div class="footer-links">
                <h3>友情链接</h3>
                <a href="https://vpnsgocn.com/" target="_blank">VPN风暴云</a>
                <a href="https://fanfanqiang.net/" target="_blank">翻茄笔记</a>
                <a href="https://clashhub.cloud/" target="_blank">VPN魔法</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 ClashX 总控 Prompt. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>`;

    fs.writeFileSync(filename, template);
});

console.log("Upgraded all auto-generated review pages to highly professional long-form format with TOC.");
